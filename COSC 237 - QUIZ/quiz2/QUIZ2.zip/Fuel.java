public interface Fuel {
    public  double checkFuel();
    public int reFuel(int type, int gallons);
}
