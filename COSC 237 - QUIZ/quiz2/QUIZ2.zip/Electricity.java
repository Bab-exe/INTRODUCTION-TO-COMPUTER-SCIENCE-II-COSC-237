public interface Electricity {
    public boolean checkBattery();
    public int charge(int capacity);
}
