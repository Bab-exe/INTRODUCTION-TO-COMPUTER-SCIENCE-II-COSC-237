
//the enum for all operation that require two complex numbers
public enum operation{
    ADD ,
    SUBTRACT,
    MULTIPLY,
    DIVIDE,
    EQUALS
}